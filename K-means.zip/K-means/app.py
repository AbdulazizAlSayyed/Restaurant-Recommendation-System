from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
import joblib
import plotly.express as px
import plotly.graph_objs as go

app = Flask(__name__)

# Load the KMeans model
kmeans = joblib.load('kmeans_model.pkl')
lasVegas = pd.read_csv('top_restaurants_lasVegas.csv')

@app.route('/')
def home():
    return render_template('model.html')  # Make sure index.html is in the 'templates' folder


@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.json
    longitude = data['longitude']
    latitude = data['latitude']
    
    # Predict the cluster for the user's coordinates
    cluster = kmeans.predict(np.array([longitude, latitude]).reshape(1, -1))[0]
    
    # Get the recommended restaurants in the same cluster
    recommended = lasVegas[lasVegas['cluster'] == cluster].iloc[:5][['name', 'latitude', 'longitude', 'review_count', 'stars']]
    
    # Create user location DataFrame for visualization
    user_location = pd.DataFrame({
        'latitude': [latitude],
        'longitude': [longitude],
        'text': ['This is you!']
    })
    
    # Generate the scatter map
    fig = px.scatter_mapbox(recommended, lat="latitude", lon="longitude", color="stars", size="review_count",
                            hover_data=['name', 'latitude', 'longitude', 'stars'], zoom=12)
    
    # Add the user's location to the map
    fig.add_scattermapbox(
        lat=user_location['latitude'],
        lon=user_location['longitude'],
        mode='markers',
        marker=dict(size=22, color='red'),
        text=user_location['text']
    )
    
    fig.update_layout(mapbox_style="open-street-map", showlegend=False)
    fig.show()

    return jsonify(recommended.to_dict(orient='records'))

if __name__ == '__main__':
    app.run(debug=True)
