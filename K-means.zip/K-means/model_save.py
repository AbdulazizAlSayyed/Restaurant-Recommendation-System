import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import joblib

# Load the dataset
df = pd.read_json('yelp_academic_dataset_business.json', lines=True)
df['Restaurants'] = df['categories'].str.contains('Restaurants')
df_restaurants = df[df['Restaurants'] == True]
lasVegas = df_restaurants[df_restaurants['state'] == 'NV']
print(lasVegas)
# Coordinates for KMeans
coords = lasVegas[['longitude', 'latitude']]

# Determine the optimal number of clusters using the Elbow Method
WCSS = []
K = range(1, 25)
for k in K:
    kmeans_model = KMeans(n_clusters=k)
    kmeans_model = kmeans_model.fit(coords)
    WCSS.append(kmeans_model.inertia_)

# Choose optimal k (e.g., 5 clusters)
kmeans = KMeans(n_clusters=5, init='k-means++')
kmeans.fit(coords)

# Add the cluster column to the DataFrame
lasVegas['cluster'] = kmeans.predict(lasVegas[['longitude', 'latitude']])
top_restaurants_lasVegas = lasVegas.sort_values(by=['review_count', 'stars'], ascending=False)

# Save the KMeans model for later use
joblib.dump(kmeans, 'kmeans_model.pkl')
top_restaurants_lasVegas.to_csv('top_restaurants_lasVegas.csv', index=False)