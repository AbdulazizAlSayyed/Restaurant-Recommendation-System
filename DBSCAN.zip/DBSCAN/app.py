from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
import joblib
import plotly.express as px

app = Flask(__name__)

# Load the DBSCAN model and dataset
dbscan = joblib.load('dbscan_model.pkl')
lasVegas = pd.read_csv('top_restaurants_lasVegas.csv')

@app.route('/')
def home():
    return render_template('index.html')  

@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.json
    longitude = float(data['longitude'])
    latitude = float(data['latitude'])
    
    input_data = np.array([[longitude, latitude]])
    cluster = dbscan.fit_predict(input_data)[0]  # DBSCAN doesn't have a predict function, using fit_predict
    
    # Get the recommended restaurants in the same cluster
    recommended = lasVegas[lasVegas['cluster'] == cluster].iloc[:5][['name', 'latitude', 'longitude', 'review_count', 'stars']]
    
    # Create user location DataFrame for visualization
    user_location = pd.DataFrame({
        'latitude': [latitude],
        'longitude': [longitude],
        'text': ['This is you!']
    })
    
    # Generate the scatter map for recommended restaurants
    fig = px.scatter_mapbox(recommended, lat="latitude", lon="longitude", color="stars", size="review_count",
                            hover_data=['name', 'latitude', 'longitude', 'stars'], zoom=12)
    
    # Add the user's location to the map
    fig.add_scattermapbox(
        lat=user_location['latitude'],
        lon=user_location['longitude'],
        mode='markers',
        marker=dict(size=22, color='red'),
        text=user_location['text']
    )
    
    fig.update_layout(mapbox_style="open-street-map", showlegend=False)
    fig.show()

    return jsonify(recommended.to_dict(orient='records'))

if __name__ == '__main__':
    app.run(debug=True)
