import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors
import joblib

# Load the dataset
df = pd.read_json('yelp_academic_dataset_business.json', lines=True)
df['Restaurants'] = df['categories'].str.contains('Restaurants')
df_restaurants = df[df['Restaurants'] == True]
lasVegas = df_restaurants[df_restaurants['state'] == 'NV']

coords = lasVegas[['longitude', 'latitude']]

# Use NearestNeighbors to find the optimal epsilon
nearest_neighbors = NearestNeighbors(n_neighbors=5)
nearest_neighbors.fit(coords)
distances, _ = nearest_neighbors.kneighbors(coords)
distances = np.sort(distances[:, 4])  # Sort the 5th nearest distances

# Choose an epsilon value based on the elbow point in the graph
epsilon = 0.1  

# Perform DBSCAN clustering
dbscan = DBSCAN(eps=epsilon, min_samples=5)
clusters = dbscan.fit_predict(coords)

# Add the cluster column to the DataFrame
lasVegas['cluster'] = clusters

# Sort by review_count and stars to find top restaurants
top_restaurants_lasVegas = lasVegas.sort_values(by=['review_count', 'stars'], ascending=False)

# Save the DBSCAN model and nearest neighbors
joblib.dump(dbscan, 'dbscan_model.pkl')
joblib.dump(nearest_neighbors, 'nearest_neighbors.pkl')

# Save the sorted top restaurants to CSV
top_restaurants_lasVegas.to_csv('top_restaurants_lasVegas.csv', index=False)

